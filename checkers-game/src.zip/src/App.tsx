import React from 'react';
import CheckersGame from './CheckersGame';
import './App.css';

function App() {
  return (
    <div className="App">
      <CheckersGame />
    </div>
  );
}

export default App;
